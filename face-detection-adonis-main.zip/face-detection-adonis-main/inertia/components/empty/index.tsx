// import React from 'react'

// const EmptyList = () => {
//   return (
    // <Empty>
    //   <EmptyHeader>
    //     <EmptyMedia variant="icon">
    //       <Icon />
    //     </EmptyMedia>
    //     <EmptyTitle>No data</EmptyTitle>
    //     <EmptyDescription>No data found</EmptyDescription>
    //   </EmptyHeader>
    //   <EmptyContent>
    //     <Button>Add data</Button>
    //   </EmptyContent>
    // </Empty>
//   )
// }

// export default EmptyList
