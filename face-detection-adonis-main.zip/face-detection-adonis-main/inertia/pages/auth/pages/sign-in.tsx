import { Button } from '@/components/ui/button'
import vine from '@vinejs/vine'
import { useForm } from 'react-hook-form'
import { vineResolver } from '@hookform/resolvers/vine'
import { Infer } from '@vinejs/vine/types'
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '~/components/ui/form'
import { Head, Link } from '@inertiajs/react'
import { Input } from '~/components/ui/input'
import { Inertia } from '@inertiajs/inertia'
import axios from 'axios'
import { callAlert } from '~/components/alert'

export default function SignIn() {
  //   const { setUsers } = useAuthStore();
  const form = useForm<Infer<typeof formSchema>>({
    resolver: vineResolver(formSchema),
    defaultValues: {
      email: '',
      password: '',
    },
  })

  async function onSubmit(values: Infer<typeof formSchema>) {
    // alert('Login function is disabled in demo version.')
    await axios
      .post('/sign-in', { ...values })
      .then((response) => {
        Inertia.visit(response.data.redirect)
      })
      .catch((error) => {
        console.log(error.response.data)
        callAlert({
          title: 'Login Failed',
          message: error.response.data || 'An error occurred during login.',
          // onConfirm: () => {},
          type: 'error',
        })
      })
  }

  return (
    <div className="flex justify-center items-center h-screen w-screen overflow-hidden">
      <Head title="Sign In" />
      <img src="/img/auth.jpg" alt="" className="w-1/2 object-cover grayscale h-screen" />
      <div className="w-1/2 p-20">
        <h1 className="text-5xl font-bold mb-8">Sign In</h1>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <div className="flex flex-col gap-5">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input placeholder="Input email" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="Input password" {...field} />
                    </FormControl>
                    <FormDescription>
                      <div className="flex justify-between">
                        <div>
                          <FormMessage />
                        </div>
                        <Link
                          href={'/forgot-password'}
                          className="text-sm hover:underline text-blue-500 dark:text-muted-foreground"
                        >
                          Forgot Password ?
                        </Link>
                      </div>
                    </FormDescription>
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full">
                Sign In
              </Button>
              <div>
                <span className="text-sm">
                  Don&apos;t have an account?{' '}
                  <Link href={'/sign-up'} className="text-sm hover:underline font-bold">
                    Sign Up
                  </Link>
                </span>
              </div>
            </div>
          </form>
        </Form>
      </div>
    </div>
  )
}

const formSchema = vine.compile(
  vine.object({
    email: vine.string().email(),
    password: vine.string().minLength(8),
  })
)
