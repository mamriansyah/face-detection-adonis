import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb'
import { Separator } from '@/components/ui/separator'
import { SidebarInset, SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar'
import { useEffect, useState } from 'react'
import { AppSidebar } from '~/components/sidebars'
import { router, usePage } from '@inertiajs/react'
import { Avatar, AvatarFallback } from '~/components/ui/avatar'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '~/components/ui/dropdown-menu'
import { LogOut, User } from 'lucide-react'
import NoLayouts from './no-layout'
import { AnimatedThemeToggler } from '~/components/ui/animated-theme-toggler'
import { Button } from '~/components/ui/button'

export default function Dashboard({ children }: { children: React.ReactNode }) {
  const { auth } = usePage().props as any

  const location = window.location.pathname

  const [breadcrumbs, setBreadcrumbs] = useState<{ name: string; url: string }[]>([])

  useEffect(() => {
    const pathSegments = location.split('/').filter(Boolean)
    const breadcrumbItems = pathSegments
      .filter((item) => item !== 'admin')
      .map((segment, index) => {
        const url = `/${pathSegments.slice(0, index + 1).join('/')}`
        return { name: segment, url }
      })
    setBreadcrumbs(breadcrumbItems)
  }, [location])

  const handleLogOut = () => {
    router.post('/sign-out')
  }

  return (
    <NoLayouts>
      <SidebarProvider>
        <AppSidebar />
        <SidebarInset>
          <header className="flex justify-between pr-4 h-16 shrink-0 items-center gap-2 transition-[width,height] ease-linear group-has-data-[collapsible=icon]/sidebar-wrapper:h-12">
            <div className="flex items-center gap-2 px-4">
              <SidebarTrigger className="-ml-1" />
              <Separator orientation="vertical" className="mr-2 data-[orientation=vertical]:h-4" />
              <Breadcrumb>
                <BreadcrumbList>
                  {breadcrumbs.map((breadcrumb, index) => (
                    <>
                      <BreadcrumbItem key={index}>
                        {index < breadcrumbs.length - 1 ? (
                          <BreadcrumbLink href={breadcrumb.url}>
                            {breadcrumb.name.charAt(0).toUpperCase() + breadcrumb.name.slice(1)}
                          </BreadcrumbLink>
                        ) : (
                          <BreadcrumbPage>
                            {breadcrumb.name.charAt(0).toUpperCase() + breadcrumb.name.slice(1)}
                          </BreadcrumbPage>
                        )}
                      </BreadcrumbItem>
                      {index < breadcrumbs.length - 1 && <BreadcrumbSeparator />}
                    </>
                  ))}
                </BreadcrumbList>
              </Breadcrumb>
            </div>
            <div className="flex flex-row gap-2 items-center">
              <Button variant={'ghost'} size={'icon'}>
                <AnimatedThemeToggler />
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger>
                  <div className="flex flex-row items-center gap-2">
                    <Avatar>
                      <AvatarFallback>{auth.user.name.charAt(0).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <span className="">Hello, {auth.user.name}</span>
                  </div>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => router.visit('/admin/profile')}>
                    <User />
                    Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleLogOut}>
                    <LogOut />
                    LogOut
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </header>
          <div className="flex flex-1 flex-col gap-4 p-4 pt-0">
            {children}
            {/* <div className="grid auto-rows-min gap-4 md:grid-cols-3">
            <div className="bg-muted/50 aspect-video rounded-xl" />
            <div className="bg-muted/50 aspect-video rounded-xl" />
            <div className="bg-muted/50 aspect-video rounded-xl" />
          </div>
          <div className="bg-muted/50 min-h-[100vh] flex-1 rounded-xl md:min-h-min" /> */}
          </div>
        </SidebarInset>
      </SidebarProvider>
    </NoLayouts>
  )
}
